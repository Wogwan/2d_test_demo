function [nomalized] = normalize(val,max,min)
nomalized = (val - min) / (max - min); 
end

