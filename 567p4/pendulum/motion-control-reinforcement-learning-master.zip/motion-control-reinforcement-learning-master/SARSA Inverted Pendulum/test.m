clc
clear all

%define hyper parameters
df = 0.9; %discount factor
a = 0.001;
b = 5;%5-10
th_err = 0.1; %theshold to split
th_n = 320; %number of samples to split
epsilon_init = 0.6;
epsilon_decay = 0.000002;

%Initial state-action space
N = 3; %number of divisions
Q_estim = initialize_Q_function(N);

n_episodes = 5000;
n_iterations = 500;

total_accumulated_reward = zeros(1,n_episodes);
t=1;
 
for n=1:n_episodes
    %Set initial state pos = pi, vel = 0
    state.pos = pi;
    state.vel = 0;
    fprintf('Learning - Episode %d\n',n);
    [action,index] = select_action_policy(Q_estim,state); 
    Q_estim(index).n = Q_estim(index).n + 1;    
    for i=1:n_iterations
        epsilon =1/(epsilon_decay*t+1/epsilon_init);%use also a global epsilon
        t=t+1;
        %fprintf('Learning - Episode %d - Iteration %d\n ',n,  i);  
        [new_state, reward] = perform_action(state, action);
        [new_action,new_index] = select_action(Q_estim, new_state, epsilon);
        q = reward + df*Q_estim(new_index).Q;
        %update number of samples in the part
        Q_estim(index).n = Q_estim(index).n + 1;    
        %update Qi value
        alpha = 1/(a *Q_estim(index).n + b); % calculate learning coefficient
        Q_estim(index).Q = Q_estim(index).Q + alpha * (q - Q_estim(index).Q);
       
        %update epsilon
%         if(Q_estim(index).epsilon - alpha/150>0)
%             Q_estim(index).epsilon = Q_estim(index).epsilon  - alpha/150;
%         end

        
        
        %update the state-action space by dividing it 
        Q_estim = update_state_space(Q_estim,q,index,th_err,th_n,state,epsilon);
        
        %update current state
        state = new_state;
        action = new_action;
        index = new_index;
    end
    
    %test every 10 episodes
    if(mod(n,10)==0)
        fprintf('Testing - Episode %d\n',n);
        %%test using the policy
        state.pos = pi;
        state.vel = 0;
        for i=1:n_iterations
           %fprintf('Testing - Episode %d - Iteration %d\n ',n,  i);
           [action,index] = select_action_policy(Q_estim,state);
           [new_state, reward] = perform_action(state, action);
           total_accumulated_reward(n) = total_accumulated_reward(n) + reward;
           %update current state
           state = new_state;
        end
    end
end


